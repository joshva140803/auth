document.getElementById('registerForm').addEventListener('submit', async (e) => { 
    e.preventDefault(); 
    const name = document.getElementById('registerName').value; 
    const email = document.getElementById('registerEmail').value; 
    const password = document.getElementById('registerPassword').value; 
    const res = await fetch('/api/auth/register', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify({ name, email, password }) 
    }); 
    const data = await res.json(); 
    if (data.msg === 'User registered successfully') { 
        document.getElementById('message').innerText = data.msg; 
        document.getElementById('registerDiv').classList.add('hidden'); 
        document.getElementById('signInDiv').classList.remove('hidden'); 
    } else { 
        document.getElementById('message').innerText = data.msg || 'Error'; 
    } 
});  
document.getElementById('signInForm').addEventListener('submit', async (e) => { 
    e.preventDefault(); 
    const email = document.getElementById('signInEmail').value; 
    const password = document.getElementById('signInPassword').value; 
    const res = await fetch('/api/auth/login', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify({ email, password }) 
    }); 
    const data = await res.json(); 
    if (data.token) { 
        localStorage.setItem('token', data.token); 
        window.location.href = '/welcome.html';    
    } else { 
        document.getElementById('message').innerText = data.msg || 'Invalid credentials'; 
    } 
}); 